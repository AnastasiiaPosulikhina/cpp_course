#define _CRT_SECURE_NO_WARNINGS
#include "AgeCounter.h"
#include <string>
#include <iostream>

AgeCounter::AgeCounter()
{
}

AgeCounter::AgeCounter(int day, int month, int year)
{
	this->day = day;
	this->month = month;
	this->year = year;
}

void AgeCounter::setDate(int day, int month, int year)
{
	this->day = day;
	this->month = month;
	this->year = year;
}

int AgeCounter::getAgeYear() {
	time_t t = time(NULL); //������������������� ������������ �������
	tm* tInfo = localtime(&t);
	AgeCounter *date = new AgeCounter(tInfo->tm_mday, tInfo->tm_mon + 1, tInfo->tm_year + 1900);
	int age;
	age = date->year - this->year;
	if (date->month - this->month < 0) {
		age--;
	}
	if ((date->month - this->month <= 0) && (date->day - this->day < 0)) {
		age--;
	}
	return age;
}

AgeCounter::~AgeCounter()
{
}
