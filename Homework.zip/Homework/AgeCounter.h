#pragma once
#include <ctime>
#include <string>
#include <iostream>

class AgeCounter
{
private:
	int day;
	int month;
	int year;
public:
	AgeCounter();
	AgeCounter(int day, int month, int year);
	void setDate(int day, int month, int year);
	int getAgeYear();
	int getDay() {
		return this->day;
	}
	int getMonth() {
		return this->month;
	}
	int getYear() {
		return this->year;
	}
	~AgeCounter();
};