#pragma once
#include "Human.h"
class Doctor:
	public Human
{
public:
	Doctor();
	Doctor(string name, string typeName, AgeCounter* birthDate, string phone, string registration_adress);
	void currentWork();
	void interaction();
	~Doctor();
};