#include "Human.h"
#include <string>

Human::Human() {
	this->name = "";
	this->birthDate = new AgeCounter();
	this->phone = "";
	this->registration_adress = "";
	this->position = "";
}

Human::Human(string name, string typeName, AgeCounter* birthDate, string phone, string registration_adress) {
	this->name = name;
	this->typeName = typeName;
	this->birthDate = birthDate;
	this->phone = phone;
	this->registration_adress = registration_adress;
}

void Human::currentWork() {}
void Human::interaction() {}

void Human::print() {
	cout << "\n�����: " << this->typeName << "\n" << endl;
	cout << "���: " << this->getName() << endl;
	cout << "�������: " << this->getAge() << endl;
	cout << "��������� �������: " << this->getPhone() << endl;
	cout << "����� �����������: " << this->getRegistration() << endl;
	cout << "���������: " << this->getPosition() << endl;
	this->currentWork();
	this->interaction();
}

void Human::printInfo() {
	cout << "���: " << this->name <<  "; ���������: " << this->position << endl;
}

int Human::getAge() {
	int age = this->birthDate->getAgeYear();
	return age;
}

string Human::getName() {
	return this->name;
}

AgeCounter* Human::getBirthDate() {
	return this->birthDate;
}

string Human::getPhone() {
	return this->phone;
}

string Human::getRegistration() {
	return this->registration_adress;
}

string Human::getPosition() {
	return this->position;
}

void Human::setName(string name) {
	this->name = name;
}

void Human::setBirthDate(AgeCounter* birthDate) {
	this->birthDate = birthDate;
}

void Human::setPhone(string phone) {
	this->phone = phone;
}

void Human::setRegistration(string registration_adress) {
	this->registration_adress = registration_adress;
}

Human::~Human() {
}