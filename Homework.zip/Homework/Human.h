#pragma once
#include <string>
#include "AgeCounter.h"
#include <iostream>

using namespace std;

class Human
{
protected:
	string position;
private:
	string name;
	string typeName;
	AgeCounter* birthDate;
	string phone;
	string registration_adress;
public:
	Human();
	Human(string name, string typeName, AgeCounter* birthDate, string phone, string registration_adress);
	virtual void currentWork();
	virtual void interaction();
	void print();
	void printInfo();
	int getAge();
	string getName();
	AgeCounter* getBirthDate();
	string getPhone();
	string getRegistration();
	string getPosition();
	void setName(string name);
	void setBirthDate(AgeCounter* birthDate);
	void setPhone(string phone);
	void setRegistration(string registration_adress);
	~Human();
};
