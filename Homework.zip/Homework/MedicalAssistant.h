#pragma once
#include "Doctor.h"
class MedicalAssistant:
	public Doctor
{
public:
	MedicalAssistant();
	MedicalAssistant(string name, string typeName, AgeCounter* birthDate, string phone, string registration_adress);
	void currentWork();
	void interaction();
	~MedicalAssistant();
};

