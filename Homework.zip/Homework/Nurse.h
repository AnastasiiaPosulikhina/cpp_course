#pragma once
#include "Human.h"
class Nurse:
	public Human
{
public:
	Nurse();
	Nurse(string name, string typeName, AgeCounter* birthDate, string phone, string registration_adress);
	void currentWork();
	void interaction();
	~Nurse();
};
